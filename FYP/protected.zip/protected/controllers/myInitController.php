<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class myInitController extends Controller{
    public function actionRun(){
        $auth=Yii::app()->authManager;
        $auth->createOperation('createUsers','Create a user');
        $bizRule ='return Yii::app()->user->id==$params["post"]->authID;';      
        $task=$auth->createTask('updateOwnPasswords','update own password',$bizRule);    
        
        $role=$auth->createRole('superadmin');
        $role->addChild('createUsers');
        $auth->assign('superadmin','5');
    }
    
    public function actionCheckAccess(){
        if (Yii::app()->user->checkAccess('createUsers')){
            echo 'authorised';
        }
        else{
            echo 'not authorized';
        }
    }
}   
    
