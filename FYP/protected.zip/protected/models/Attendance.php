<?php

/**
 * This is the model class for table "attendance".
 *
 * The followings are the available columns in table 'attendance':
 * @property integer $Attendance_ID
 * @property integer $Lesson_ID
 * @property integer $Student_ID
 * @property integer $Student_Presence
 * @property integer $Notice
 * @property integer $Staff_Presence
 * @property integer $Reschedule
 * @property string $Feedback
 * @property string $Remarks
 */
class Attendance extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'attendance';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			//array('Lesson_ID, Student_ID, Student_Presence, Notice, Staff_Presence, Reschedule, Feedback, Remarks', 'required'),
			array('Lesson_ID, Student_ID, Student_Presence, Staff_Presence, Reschedule', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('Attendance_ID, Lesson_ID, Student_ID, Student_Presence, Staff_Presence, Reschedule, Remarks', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'Attendance_ID' => 'Attendance',
			'Lesson_ID' => 'Lesson',
			'Student_ID' => 'Student',
			'Student_Presence' => 'Student Presence',
			
			'Staff_Presence' => 'Staff Presence',
			'Reschedule' => 'Reschedule',
			
			'Remarks' => 'Remarks',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('Attendance_ID',$this->Attendance_ID);
		$criteria->compare('Lesson_ID',$this->Lesson_ID);
		$criteria->compare('Student_ID',$this->Student_ID);
		$criteria->compare('Student_Presence',$this->Student_Presence);
		
		$criteria->compare('Staff_Presence',$this->Staff_Presence);
		$criteria->compare('Reschedule',$this->Reschedule);
		
		$criteria->compare('Remarks',$this->Remarks,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Attendance the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
