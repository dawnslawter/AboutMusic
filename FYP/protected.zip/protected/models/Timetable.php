<?php

/**
 * This is the model class for table "timetable".
 *
 * The followings are the available columns in table 'timetable':
 * @property integer $Lesson_ID
 * @property integer $Staff_ID
 * @property integer $Course_ID
 * @property integer $Venue
 * @property integer $Duration
 * @property integer $Date_Scheduled
 * @property integer $Time_Scheduled
 *
 * The followings are the available model relations:
 * @property Login $staff
 * @property Course $course
 * @property Studio $venue
 */
class Timetable extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'timetable';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('Staff_ID, Course_ID, Venue, Duration, Date_Scheduled, Time_Scheduled', 'required'),
			array('Staff_ID, Course_ID, Venue, Duration, Date_Scheduled, Time_Scheduled', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('Lesson_ID, Staff_ID, Course_ID, Venue, Duration, Date_Scheduled, Time_Scheduled', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'staff' => array(self::BELONGS_TO, 'Login', 'Staff_ID'),
			'course' => array(self::BELONGS_TO, 'Course', 'Course_ID'),
			'venue' => array(self::BELONGS_TO, 'Studio', 'Venue'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'Lesson_ID' => 'Lesson',
			'Staff_ID' => 'Staff',
			'Course_ID' => 'Course',
			'Venue' => 'Venue',
			'Duration' => 'Duration',
			'Date_Scheduled' => 'Date Scheduled',
			'Time_Scheduled' => 'Time Scheduled',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('Lesson_ID',$this->Lesson_ID);
		$criteria->compare('Staff_ID',$this->Staff_ID);
		$criteria->compare('Course_ID',$this->Course_ID);
		$criteria->compare('Venue',$this->Venue);
		$criteria->compare('Duration',$this->Duration);
		$criteria->compare('Date_Scheduled',$this->Date_Scheduled);
		$criteria->compare('Time_Scheduled',$this->Time_Scheduled);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Timetable the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
