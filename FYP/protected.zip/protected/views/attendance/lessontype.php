<?php
    $this->breadcrumbs=array(
	"Management"=>array('site/page','view'=>'management'),
	"Attendance Management"=>('admin'),
    );

    $this->menu=array(
            //array('label'=>'List Attendance', 'url'=>array('index')),
            array('label'=>'Manage Attendance', 'url'=>array('admin')),
    );

    echo '<h1>Course Type</h1>';
    $coursetype= CourseType::model()->findAll();
    $num= 1;
    
    echo '<table>';
    
    foreach($coursetype as $value=>$result){
        $criteria = new CDbCriteria();
        $criteria->condition = 'Course_Type=:id';
        $criteria->params = array(':id'=>$result->Type_ID);
        $course=Course::model()->findAll($criteria);
        if($result->Type_ID%2==1){
            echo '<tr>';
        }
        echo '<td>';
        echo '<h2>'.$result->Course_Type.'</h2>';
       
        
        foreach($course as $value1=>$result1){
                echo '<li>';
                echo CHtml::link("$result1->Course_Name",array('create', 'Course_ID'=>$result1->Course_ID));;
                echo '</li>';
        }
        
         echo '<br>';
        echo '</td>';
        
        if($result->Type_ID%2==1){
            echo '</tr>';
            }
        
            
        }
    
    
    echo '</table>';
    
?>