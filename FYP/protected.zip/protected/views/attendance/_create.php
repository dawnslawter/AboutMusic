<?php
/* @var $this AttendanceController */
/* @var $model Attendance */
/* @var $form CActiveForm */
$course = isset($_GET['Course_ID'])? $_GET['Course_ID'] : 1;
$date = new DateTime();
$formatdate=$date->format('Y-m-d');

?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'attendance-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'Lesson_ID'); ?>
		<?php
                                                $criteria = new CDbCriteria();
                                                $criteria->condition = 'Course_ID=:id';
                                                $criteria->params = array(':id'=>$course);
                                                $data=Timetable::model()->findAll($criteria);
                                                $arr = array();
                                                foreach($data as $value1=>$result1){
                                                        if($result1->Date_Scheduled>=$formatdate){
                                                            $staff=Userdata::model()->findByAttributes(array('User_ID'=>$result1->Staff_ID));
                                                            
                                                            array_push($arr,array('Value'=>$result1->Lesson_ID,'Name'=>$staff->First_Name.' '.$staff->Last_Name.' ('.$result1->Date_Scheduled.' / '.$result1->Time_Scheduled.')'));
                                                        }
                                                }
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Lesson_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'Value',
                                                                'Name'
                                                                
                                                                )); 
                                                
                                        ?>
		<?php echo $form->error($model,'Lesson_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Student_ID'); ?>
		<?php 
                                                    $data2=Registration::model()->findAll($criteria);
                                                     $arr2 = array();
                                                     foreach($data2 as $value1=>$result1){
                                                            $student=Student::model()->findByAttributes(array('Student_ID'=>$result1->Student_ID));
                                                            if($student->Child_ID==0){
                                                                $member=  UserData::model()->findByAttributes(array('Member_ID'=>$student->Member_ID));
                                                                array_push($arr2, array('Value'=>$student->Student_ID,'Name'=>$member->First_Name.' '.$member->Last_Name));
                                                            }
                                                            else{
                                                                $child=  Child::model()->findByAttributes(array('Member_ID'=>$student->Member_ID,'Child_ID'=>$student->Child_ID));
                                                                array_push($arr2,array('Value'=>$student->Student_ID,'Name'=>$child->First_Name.' '.$child->Last_Name));
                                                            }
                                                    }
                                                    echo $form->dropDownList(
                                                        $model,
                                                        'Student_ID',
                                                        CHtml::listData(
                                                                $arr2,
                                                                'Value',
                                                                'Name'
                                                                
                                                                )); 
                                                    ?>
		<?php echo $form->error($model,'Student_ID'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->