<?php
/* @var $this AttendanceController */
/* @var $model Attendance */

$this->breadcrumbs=array(
	"Management"=>array('site/page','view'=>'management'),
	"Attendance Management"=>('admin'),
	$model->Attendance_ID,
);

$this->menu=array(
	//array('label'=>'List Attendance', 'url'=>array('index')),
	array('label'=>'Add Student to Lesson', 'url'=>array('lessontype')),
	array('label'=>'Update Attendance', 'url'=>array('update', 'id'=>$model->Attendance_ID)),
	array('label'=>'Delete Attendance', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Attendance_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Attendance', 'url'=>array('admin')),
);
?>

<h1>View Attendance #<?php echo $model->Attendance_ID; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'Attendance_ID',
		'Lesson_ID',
		'Student_ID',
		'Student_Presence',
		'Notice',
		'Staff_Presence',
		'Reschedule',
		'Feedback',
		'Remarks',
	),
)); ?>
