<?php
/* @var $this AttendanceController */
/* @var $model Attendance */
$lesson = isset($_GET['lesson'])? $_GET['lesson'] : 1;
$this->breadcrumbs=array(
	"Today's Lesson"=>array('timetable/checkLesson'),
	'Lesson #'.$lesson
);

?>

<h1>Students in Lesson</h1>
<?php 

$criteria = new CDbCriteria();
$criteria->condition = 'Lesson_ID=:id';
$criteria->params = array(':id'=>$lesson);
$data= Attendance::model()->findAll($criteria);

echo '<table>
                <tr>
                    <td>Student</td>
                    <td>Attendance Status</td>
                    <td></td></tr>';
foreach($data as $value=>$result){
    echo '<tr>';
    $student=Student::model()->findByAttributes(array('Student_ID'=>$result->Student_ID));
    if($student->Child_ID==0){
        $member=  UserData::model()->findByAttributes(array('Member_ID'=>$student->Member_ID));
        echo '<td>'.$member->First_Name.' '.$member->Last_Name.'</td>';
        }
    else{
        $child=  Child::model()->findByAttributes(array('Member_ID'=>$student->Member_ID,'Child_ID'=>$student->Child_ID));
        echo '<td>'.$child->First_Name.' '.$child->Last_Name.'</td>';
        }
    echo '<td>';
    if($result->Staff_Presence==0){
        echo'Not Taken';
    }
    else{
        echo 'Taken';
    }
    echo '</td><td>';
    
    echo CHtml::link('Take Attendance',array('attendance/attendance','id'=>$result->Attendance_ID));
    echo '/';
    $feedback = Feedback::model()->findByAttributes(array('Attendance_ID'=>$result->Attendance_ID));
    $count= count(Feedback::model()->findByAttributes(array('Attendance_ID'=>$result->Attendance_ID)));
    
    
    if($count==1){
        echo CHtml::link('Give Feedback',array('feedback/update','id'=>$feedback->Feedback_ID));
    }
    else{
        echo CHtml::link('Give Feedback',array('feedback/create','id'=>$result->Attendance_ID));
    }    
    echo'</td></tr>';
    }

echo'</table>';
?>