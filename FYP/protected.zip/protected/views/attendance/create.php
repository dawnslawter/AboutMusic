<?php
/* @var $this AttendanceController */
/* @var $model Attendance */
$course = isset($_GET['Course_ID'])? $_GET['Course_ID'] : 1;
$type=Course::model()->findByAttributes(array('Course_ID'=>$course));
$this->breadcrumbs=array(
	"Management"=>array('site/page','view'=>'management'),
	"Attendance Management"=>('admin'),
	'Add Student to Lesson'=>('lessontype'),
                    $type->Course_Name
);

$this->menu=array(
	//array('label'=>'List Attendance', 'url'=>array('index')),
	array('label'=>'Manage Attendance', 'url'=>array('admin')),
);
?>

<h1>Add Student to Lesson</h1>

<?php $this->renderPartial('_create', array('model'=>$model)); ?>