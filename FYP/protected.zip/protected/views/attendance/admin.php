<?php
/* @var $this AttendanceController */
/* @var $model Attendance */

$this->breadcrumbs=array(
	"Management"=>array('site/page','view'=>'management'),
	"Attendance Management",
);

$this->menu=array(
	//array('label'=>'List Attendance', 'url'=>array('index')),
	array('label'=>'Add Student to Lesson', 'url'=>array('lessontype')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#attendance-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Attendances</h1>

<p>
You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'attendance-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'Attendance_ID',
		'Lesson_ID',
		'Student_ID',
		'Student_Presence',
		
		'Staff_Presence',
		/*
		'Reschedule',
		
		'Remarks',
		*/
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
