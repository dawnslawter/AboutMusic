<?php
/* @var $this AttendanceController */
/* @var $model Attendance */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'Attendance_ID'); ?>
		<?php echo $form->textField($model,'Attendance_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Lesson_ID'); ?>
		<?php echo $form->textField($model,'Lesson_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Student_ID'); ?>
		<?php echo $form->textField($model,'Student_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Student_Presence'); ?>
		<?php echo $form->textField($model,'Student_Presence'); ?>
	</div>

	
	<div class="row">
		<?php echo $form->label($model,'Staff_Presence'); ?>
		<?php echo $form->textField($model,'Staff_Presence'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Reschedule'); ?>
		<?php echo $form->textField($model,'Reschedule'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Remarks'); ?>
		<?php echo $form->textArea($model,'Remarks',array('rows'=>6, 'cols'=>50)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->