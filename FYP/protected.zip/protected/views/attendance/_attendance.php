<?php
/* @var $this AttendanceController */
/* @var $model Attendance */
/* @var $form CActiveForm */;
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'attendance-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>true,
    
)); ?>

	

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'Lesson_ID'); ?>
		<?php echo $form->textField($model,'Lesson_ID', array('readonly'=>true)); ?>
		<?php echo $form->error($model,'Lesson_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Student_ID'); ?>
		<?php echo $form->textField($model,'Student_ID', array('readonly'=>true)); ?>
		<?php echo $form->error($model,'Student_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Student_Presence'); ?>
		<?php 
                                                    $dat= array(array('Value'=>0,"Name"=>'Absent'),array('Value'=>1,"Name"=>'Present'));
                                                    
                                                    if ($model->Staff_Presence==0){
                                                        echo $form->dropDownList(
                                                        $model,
                                                        'Student_Presence',
                                                        CHtml::listData(
                                                                $dat,
                                                                'Value','Name'
                                                                ),
                                                        array(
                                                                'options' =>array(
                                                                    '1' => array(
                                                                        'selected' => "selected"
                                                                    )
                                                                )
                                                            )
                                                        ); 
                                                    }
                                                    else{
                                                         echo $form->dropDownList(
                                                        $model,
                                                        'Student_Presence',
                                                        CHtml::listData(
                                                                $dat,
                                                                'Value','Name'
                                                                ),
                                                        array(
                                                                'disabled'=>true,
                                                                
                                                            )
                                                        ); 
                                                    }
                                                    ?>
		<?php echo $form->error($model,'Student_Presence'); ?>
	</div>

	
	

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->