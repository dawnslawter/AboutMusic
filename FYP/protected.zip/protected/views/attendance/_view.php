<?php
/* @var $this AttendanceController */
/* @var $data Attendance */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Attendance_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Attendance_ID), array('view', 'id'=>$data->Attendance_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Lesson_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Lesson_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Student_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Student_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Student_Presence')); ?>:</b>
	<?php echo CHtml::encode($data->Student_Presence); ?>
	<br />


	<b><?php echo CHtml::encode($data->getAttributeLabel('Staff_Presence')); ?>:</b>
	<?php echo CHtml::encode($data->Staff_Presence); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Reschedule')); ?>:</b>
	<?php echo CHtml::encode($data->Reschedule); ?>
	<br />

	<?php /*
	
	<b><?php echo CHtml::encode($data->getAttributeLabel('Remarks')); ?>:</b>
	<?php echo CHtml::encode($data->Remarks); ?>
	<br />

	*/ ?>

</div>