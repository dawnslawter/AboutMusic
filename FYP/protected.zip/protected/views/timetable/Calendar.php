<?php
$studio = isset($_GET['studio'])? $_GET['studio'] : 1;

$dateValue = getDate();
$month=$dateValue['month'];
$nmonth=(int)$dateValue['month'];
$year=(int)$dateValue['year'];


$checkmonth=isset($_GET['month']) ? $_GET['month'] : date('m',strtotime($month));;
$checkyear=isset($_GET['year'])? $_GET['year'] : $year;
$venue=studio::model()->findByAttributes(array('Studio_ID'=>$studio));
$this->breadcrumbs=array(
                    "Management"=>array('site/page','view'=>'management'),
	"Lesson Management"=>array('admin'),
                    "Calendar",
                    $venue->Studio_Name
        );

$studiono=count(timetable::model()->findByAttributes(array('Venue'=>$studio)));
echo '<table><tr>';
    $venuetable=studio::model()->findAll();
    foreach($venuetable as $value=>$result){
            echo'<td style="text-align: center">';
            echo CHtml::link($result->Studio_Name,array('Calendar','month'=>$checkmonth,'year'=>$checkyear,'studio'=>$result->Studio_ID));
            echo'</td>'.'&nbsp';
    }

echo '</tr></table>';


$this->menu=array(
	array('label'=>'Manage Lessons', 'url'=>array('admin')),
	array('label'=>'Create New Lesson', 'url'=>array('lesson')),
);

$count=count(timetable::model()->findAll());
if ($count !=0){
        $events=array();
        $num=1;
        $datecheck=null;
        $data=timetable::model()->findAll();
        foreach($data as $value=>$result){
            if($result->Venue==$studio){
                    $timestamp=strtotime($result->Date_Scheduled);
                    if($datecheck==null){
                        array_push($events, array('rdate'=>$timestamp,'html'=>$result->Date_Scheduled.'<br><br>'));
                    }
                    elseif($datecheck!=$timestamp){
                        array_push($events, array('rdate'=>$timestamp,'html'=>$result->Date_Scheduled.'<br><br>'));
                    }
                    $datecheck=$timestamp;
            }
            
        }
        
}
else{
    $event = null;
}
$this->widget('ext.calendar-advance.AdvanceCalendarWidget',array('month'=>$nmonth, 'year'=>$year, 'events'=>$events));

?>