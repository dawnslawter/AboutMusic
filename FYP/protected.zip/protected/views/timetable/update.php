<?php
/* @var $this TimetableController */
/* @var $model Timetable */

$this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
	'Lesson Management'=>array('admin'),
	'Update',
);

$this->menu=array(
	array('label'=>'Create New Lesson', 'url'=>array('lesson')),
	array('label'=>'View Lesson Details', 'url'=>array('view', 'id'=>$model->Lesson_ID)),
	array('label'=>'Manage Lessons', 'url'=>array('admin')),
                    array('label'=>'Manage Timetable', 'url'=>array('Calendar')),
);
?>

<h1>Update Lesson #<?php echo $model->Lesson_ID; ?>'s Details </h1>

<?php $this->renderPartial('_updateby', array('model'=>$model)); ?>