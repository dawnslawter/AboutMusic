<?php


        $this->breadcrumbs=array(
	"Today's Lesson",
        );
        
        
        $date = new DateTime();
        $formatdate=$date->format('Y-m-d'); 
        $count=Timetable::model()->countByAttributes(array('Staff_ID'=>Yii::app()->user->id,'Date_Scheduled'=> $formatdate));
        
        if($count!=0){
            
        echo "<h1>Today's Lesson</h1>";
       
        $criteria = new CDbCriteria();
        $criteria->condition = 'Staff_ID=:id';
        $criteria->params = array(':id'=>Yii::app()->user->id);
        $data=Timetable::model()->findAll($criteria);
        foreach($data as $value=>$result){
            if($result->Date_Scheduled==$formatdate){
                    $data1=Timetable::model()->findByAttributes(array('Lesson_ID'=>$result->Lesson_ID));
                    $course=Course::model()->findByAttributes(array('Course_ID'=>$data1->Course_ID));
                    $studio=Studio::model()->findByAttributes(array('Studio_ID'=>$data1->Venue));
                    $this->widget('zii.widgets.CDetailView', array(
                        'data'=>$data1,
                        'attributes'=>array(
                                'Lesson_ID',
                                array(        
                                                                'name' => 'Course',
                                                                'value' => CHtml::encode($course->Course_Name)
                                                            ),
                                array(        
                                                                'name' => 'Venue',
                                                                'value' => CHtml::encode($studio->Studio_Name)
                                                            ),
                                'Duration',
                                                        'Time_Scheduled'
                        ),


                    ));


                    echo CHtml::link('Take Attendance',array('attendance/checkStud','lesson'=>$result->Lesson_ID));
                    echo '<br><br><br>';
                }
            }
        
        }
        else{
            echo'<h1>No Lessons today</h1>';
            
        }
?>

  