<?php
/* @var $this TimetableController */
/* @var $model Timetable */
/* @var $form CActiveForm */

$this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
	'Lesson Management'=>array('admin'),
                    'Create New Lesson'
);

$this->menu=array(
                    array('label'=>'Manage Lessons', 'url'=>array('admin')),
	array('label'=>'Manage Timetable', 'url'=>array('Calendar')),
	
);
?>

<h1>Select Lesson Type</h1>
<?php
        $data=  CourseType::model()->findAll();
        foreach($data as $value=>$result){
             
            echo CHtml::link("$result->Course_Type",array('create', 'coursetype'=>$result->Type_ID));
            echo '<br><br>';
            
        }
?>