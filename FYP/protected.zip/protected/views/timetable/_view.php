<?php
/* @var $this TimetableController */
/* @var $data Timetable */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Lesson_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Lesson_ID), array('view', 'id'=>$data->Lesson_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Staff_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Staff_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Course_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Venue')); ?>:</b>
	<?php echo CHtml::encode($data->Venue); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Duration')); ?>:</b>
	<?php echo CHtml::encode($data->Duration); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Date_Scheduled')); ?>:</b>
	<?php echo CHtml::encode($data->Date_Scheduled); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Time_Scheduled')); ?>:</b>
	<?php echo CHtml::encode($data->Time_Scheduled); ?>
	<br />


</div>