<?php
/* @var $this TimetableController */
/* @var $model Timetable */

$this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
	'Lesson Management'=>array('admin'),
	'Create',
);

$this->menu=array(
	array('label'=>'View Timetable', 'url'=>array('Calendar')),
	array('label'=>'Manage Lesson', 'url'=>array('admin')),
);
?>

<h1>Create New Lesson</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>