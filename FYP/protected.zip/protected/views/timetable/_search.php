<?php
/* @var $this TimetableController */
/* @var $model Timetable */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'Lesson_ID'); ?>
		<?php echo $form->textField($model,'Lesson_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Staff_ID'); ?>
		<?php $criteria = new CDbCriteria();
                                                $criteria->condition = 'role>=:id';
                                                $criteria->params = array(':id'=>'3');
                                                $arr = array();
                                                $dat=Login::model()->findAll($criteria);
                                                //$dat= CHtml::listData($dat,'id','id');
                                                
                                                foreach($dat as $value=>$result){
                                                    $teach=UserData::model()->findByAttributes(array('User_ID'=>$result->id));
                                                    
                                                    array_push($arr, array('Staff_ID'=>$teach->User_ID,'Name'=>$teach->First_Name.' '.$teach->Last_Name));
                                                }
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Staff_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'Staff_ID',
                                                                'Name'
                                                                
                                                                ),
                                                        array('prompt'=>'Select Staff')
                                                        );  ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Course_ID'); ?>
		<?php 
                                        $data1= Course::model()->findAll();
                                        
                                        echo $form->dropDownList(
                                                        $model,
                                                        'Course_ID',
                                                        CHtml::listData(
                                                                $data1,
                                                                'Course_ID',
                                                                'Course_Name'
                                                                ),
                                                array('prompt'=>'Select Course')
                                                ); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Venue'); ?>
		<?php echo $form->dropDownList(
                                                        $model,
                                                        'Venue',
                                                        CHtml::listData(
                                                                Studio::model()->findAll(),
                                                                'Studio_ID',
                                                                'Studio_Name'
                                                                ),
                                                                array('prompt'=>'Select Venue')
                        ); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Duration'); ?>
		<?php echo $form->textField($model,'Duration'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Date_Scheduled'); ?>
		<?php echo $form->textField($model,'Date_Scheduled'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Time_Scheduled'); ?>
		<?php echo $form->textField($model,'Time_Scheduled'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->