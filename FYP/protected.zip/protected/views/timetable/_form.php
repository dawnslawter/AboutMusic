<?php
/* @var $this TimetableController */
/* @var $model Timetable */
/* @var $form CActiveForm */
$type = isset($_GET['coursetype'])? $_GET['coursetype'] : 1;
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'timetable-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php
                                        echo $form->labelEx($model,'Staff_ID');
                                                $criteria = new CDbCriteria();
                                                $criteria->condition = 'Course_Type=:id';
                                                $criteria->params = array(':id'=>$type);
                                                $arr = array();
                                                $dat=Teaching::model()->findAll($criteria);
                                                //$dat= CHtml::listData($dat,'id','id');
                                                
                                                foreach($dat as $value=>$result){
                                                    $teach=UserData::model()->findByAttributes(array('User_ID'=>$result->Staff_ID));
                                                    
                                                    array_push($arr, array('Staff_ID'=>$teach->User_ID,'Name'=>$teach->First_Name.' '.$teach->Last_Name));
                                                }
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Staff_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'Staff_ID',
                                                                'Name'
                                                                
                                                                )); 
                                                        
                                                
                                        ?>
	</div>

	<div class="Course_ID">
		<?php echo $form->labelEx($model,'Course_ID');
		
                                        $criteria1 = new CDbCriteria();
                                        $criteria1->condition = 'Course_Type=:id';
                                        $criteria1->params = array(':id'=>$type);
                                        $data1= Course::model()->findAll($criteria1);
                                        
                                        echo $form->dropDownList(
                                                        $model,
                                                        'Course_ID',
                                                        CHtml::listData(
                                                                $data1,
                                                                'Course_ID',
                                                                'Course_Name'
                                                                ));
                 
                                                                
		echo $form->error($model,'Course_ID'); ?>
	</div>

	<div class="row">
		<?php
                                        echo $form->labelEx($model,'Venue');
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Venue',
                                                        CHtml::listData(
                                                                Studio::model()->findAll(),
                                                                'Studio_ID',
                                                                'Studio_Name'
                                                                )); 
                                                        
                                                
                                        ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Duration'); ?>
		<?php echo $form->textField($model,'Duration', array('placeholder'=>'in mins')); ?>
		<?php echo $form->error($model,'Duration'); ?>
                                       
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Date_Scheduled'); ?>
		<?php echo $form->textField($model,'Date_Scheduled', array('placeholder'=>'yyyy-mm-dd')); ?>
		<?php echo $form->error($model,'Date_Scheduled'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Time_Scheduled'); ?>
		<?php echo $form->textField($model,'Time_Scheduled', array('placeholder'=>'hh:mm:ss')); ?>
		<?php echo $form->error($model,'Time_Scheduled'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->