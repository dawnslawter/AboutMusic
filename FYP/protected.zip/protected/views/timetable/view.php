<?php
/* @var $this TimetableController */
/* @var $model Timetable */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Lesson Management'=>array('admin'),
	$model->Lesson_ID,
);

$this->menu=array(
	array('label'=>'Create Lesson', 'url'=>array('lesson')),
	array('label'=>'Update Lesson Details', 'url'=>array('update', 'id'=>$model->Lesson_ID)),
	array('label'=>'Delete Lesson', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Lesson_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Lessons', 'url'=>array('admin')),
                    array('label'=>'Manage Timetable', 'url'=>array('Calendar')),
);
?>

<h1>View Lesson Details</h1>

<?php 
$member=UserData::model()->findByAttributes(array('User_ID'=>$model->Staff_ID));
$course=Course::model()->findByAttributes(array('Course_ID'=>$model->Course_ID));
$studio=Studio::model()->findByAttributes(array('Studio_ID'=>$model->Venue));
$this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'Lesson_ID',
		array(        
                                                'name' => 'Staff',
                                                'value' => CHtml::encode($member->First_Name.' '.$member->Last_Name)
                                            ),
		array(        
                                                'name' => 'Course',
                                                'value' => CHtml::encode($course->Course_Name)
                                            ),
		array(        
                                                'name' => 'Venue',
                                                'value' => CHtml::encode($studio->Studio_Name)
                                            ),
		'Duration',
		'Date_Scheduled',
		'Time_Scheduled',
	),
)); ?>

