<?php
/* @var $this TimetableController */
/* @var $model Timetable */

$this->breadcrumbs=array(
                    "Management"=>array('site/page','view'=>'management'),
	'Lesson Management',
	
);

$this->menu=array(
	array('label'=>'View Timetable', 'url'=>array('Calendar')),
	array('label'=>'Create New Lesson', 'url'=>array('lesson')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#timetable-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Lesson</h1>

<p>
You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'timetable-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'Lesson_ID',
		array(            // display 'author.username' using an expression
                                            'name'=>'Staff_ID',
                                            'value'=>'UserData::model()->findByAttributes(array("User_ID"=>$data->Staff_ID))->First_Name." ".UserData::model()->findByAttributes(array("User_ID"=>$data->Staff_ID))->Last_Name',
                                        ),
		array(            // display 'author.username' using an expression
                                            'name'=>'Course_ID',
                                            'value'=>'Course::model()->findByAttributes(array("Course_ID"=>$data->Course_ID))->Course_Name',
                                        ),
		array(            // display 'author.username' using an expression
                                            'name'=>'Venue',
                                            'value'=>'Studio::model()->findByAttributes(array("Studio_ID"=>$data->Venue))->Studio_Name',
                                        ),
		'Duration',
		'Date_Scheduled',
		
		'Time_Scheduled',
		
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
