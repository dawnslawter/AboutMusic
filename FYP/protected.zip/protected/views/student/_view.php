<?php
/* @var $this StudentController */
/* @var $data Student */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Student_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Student_ID), array('view', 'id'=>$data->Student_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Member_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Member_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Child_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Child_ID); ?>
	<br />


</div>