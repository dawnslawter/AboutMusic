<?php
/* @var $this StudentController */
/* @var $model Student */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Student Management'=>array('admin'),
	'Update Student ID '.$model->Student_ID,
);

$this->menu=array(
	//array('label'=>'List Student', 'url'=>array('index')),
	array('label'=>'Register New Student (Member)', 'url'=>array('create')),
                    array('label'=>'Register New Student (Child)', 'url'=>array('createc')),
	array('label'=>"View Student's Information", 'url'=>array('view', 'id'=>$model->Student_ID)),
	array('label'=>'Manage Students', 'url'=>array('admin')),
);
?>

<h1>Update Student <?php echo $model->Student_ID; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>