<?php
/* @var $this StudentController */
/* @var $model Student */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'student-createc-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// See class documentation of CActiveForm for details on this,
	// you need to use the performAjaxValidation()-method described there.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	

	<div class="row">
	<?php
                            echo $form->labelEx($model,'Child_ID');
                           
                            $arr = array();
                            $dat=Child::model()->findAll();
                            foreach($dat as $value=>$result){
                                $child=Login::model()->findByAttributes(array('id'=>$result->Member_ID));
                                  
                                array_push($arr, array('PC_ID'=>$result->PC_ID,'Name'=>$result->First_Name.' '.$result->Last_Name.' ('.$child->username.', Child #'.$result->Child_ID.')'));
                            }
                            
                            
                                echo $form->dropDownList(
                                    $model,
                                    'Child_ID',
                                    CHtml::listData(
                                            $arr,
                                            'PC_ID',
                                            'Name'
                                            )
                                    );
	
                                ?>
                        </div>


	<div class="row buttons">
		<?php echo CHtml::submitButton('Submit'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->