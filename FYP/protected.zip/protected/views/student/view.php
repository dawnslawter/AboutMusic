<?php
/* @var $this StudentController */
/* @var $model Student */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Student Management'=>array('admin'),
	$model->Student_ID,
);

$this->menu=array(
	//array('label'=>'List Student', 'url'=>array('index')),
	array('label'=>'Register New Student (Member)', 'url'=>array('create')),
                    array('label'=>'Register New Student (Child)', 'url'=>array('createc')),
	array('label'=>'Update Student Information', 'url'=>array('update', 'id'=>$model->Student_ID)),
	array('label'=>'Delete Student', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Student_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Students', 'url'=>array('admin')),
);
?>

<h1>View Student #<?php echo $model->Student_ID; ?></h1>

<?php 
    $member= UserData::model()->findByAttributes(array('User_ID'=>$model->Member_ID));
    if($model->Child_ID!=0){
        $child=Child::model()->findByAttributes(array('Child_ID'=>$model->Child_ID,'Member_ID'=>$model->Member_ID));
           $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'Student_ID',
		array(        
                                                'name' => 'Member',
                                                'value' => CHtml::encode($member->First_Name.' '.$member->Last_Name)
                                            ),
		array(        
                                                'name' => 'Child',
                                                'value' => CHtml::encode($child->First_Name.' '.$child->Last_Name)
                                            ),
	),
    )); 
        
    }
    else{
           $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'Student_ID',
		array(        
                                                'name' => 'Member',
                                                'value' => CHtml::encode($member->First_Name.' '.$member->Last_Name)
                                            ),
		array(        
                                                'name' => 'Child',
                                                'value' => CHtml::encode('----')
                                            ),
	),
)); 
    }
    
    
    
 
    
    ?>
