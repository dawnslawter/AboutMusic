<?php
/* @var $this StudentController */
/* @var $model Student */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Student Management'=>array('admin'),
	'Register New Student',
);

$this->menu=array(
	//array('label'=>'List Student', 'url'=>array('index')),
	array('label'=>'Manage Student', 'url'=>array('admin')),
);
?>
<table>
    <tr>
        <td style="text-align: center"><?php
            echo CHtml::link('Member',array('create'));
        ?></td>
        <td style="text-align: center"><?php
            echo CHtml::link("Member's Child",array('createc'));
        ?></td>
    </tr>
</table>


<h1>Register New Student</h1>

<?php 

    $this->renderPartial('_formc', array('model'=>$model)); 

        

?>