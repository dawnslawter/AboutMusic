<?php
/* @var $this StudioController */
/* @var $data Studio */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Studio_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Studio_ID), array('view', 'id'=>$data->Studio_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Capacity')); ?>:</b>
	<?php echo CHtml::encode($data->Capacity); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Studio_Name')); ?>:</b>
	<?php echo CHtml::encode($data->Studio_Name); ?>
	<br />


</div>