<?php
/* @var $this StudioController */
/* @var $model Studio */

$this->breadcrumbs=array(
	'Management'=>array('site/page', 'view'=>'management'),
                    'Studio Management'=>array('admin'),
                    'Update Studio'
);

$this->menu=array(
	//array('label'=>'List Studio', 'url'=>array('index')),
	array('label'=>'Add New Studio', 'url'=>array('create')),
	array('label'=>'View Studio', 'url'=>array('view', 'id'=>$model->Studio_ID)),
	array('label'=>'Manage Studios', 'url'=>array('admin')),
);
?>

<h1>Update <?php echo $model->Studio_Name; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>