<?php
/* @var $this StudioController */
/* @var $model Studio */

$this->breadcrumbs=array(
	'Management'=>array('site/page', 'view'=>'management'),
                    'Studio Management'=>array('admin'),
                    $model->Studio_Name,
);

$this->menu=array(
	array('label'=>'List Studio', 'url'=>array('index')),
	array('label'=>'Create Studio', 'url'=>array('create')),
	array('label'=>'Update Studio', 'url'=>array('update', 'id'=>$model->Studio_ID)),
	array('label'=>'Delete Studio', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Studio_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Studio', 'url'=>array('admin')),
);
?>

<h1>View <?php echo $model->Studio_Name; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'Studio_ID',
		'Capacity',
		'Studio_Name',
	),
)); ?>
