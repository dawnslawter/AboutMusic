<?php
/* @var $this StudioController */
/* @var $model Studio */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'Studio_ID'); ?>
		<?php echo $form->textField($model,'Studio_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Capacity'); ?>
		<?php echo $form->textField($model,'Capacity'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Studio_Name'); ?>
		<?php echo $form->textField($model,'Studio_Name',array('size'=>60,'maxlength'=>99)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->