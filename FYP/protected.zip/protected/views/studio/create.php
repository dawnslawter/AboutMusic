<?php
/* @var $this StudioController */
/* @var $model Studio */

$this->breadcrumbs=array(
	'Management'=>array('site/page', 'view'=>'management'),
                    'Studio Management'=>array('admin'),
                    'Add New Studio'
);

$this->menu=array(
	//array('label'=>'List Studio', 'url'=>array('index')),
	array('label'=>'Manage Studio', 'url'=>array('admin')),
);
?>

<h1>Add New Studio</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>