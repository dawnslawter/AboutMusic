<?php
/* @var $this CourseController */
/* @var $model Course */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Course Management'=>array('admin'),
	$model->Course_Name,
);

$this->menu=array(
	//array('label'=>'List Course', 'url'=>array('index')),
	array('label'=>'Create New Course', 'url'=>array('create')),
	array('label'=>'Update Course Information', 'url'=>array('update', 'id'=>$model->Course_ID)),
	array('label'=>'Delete Course', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Course_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Courses', 'url'=>array('admin')),
);
?>

<h1>View Course #<?php echo $model->Course_ID; ?></h1>

<?php 
$coursetype=CourseType::model()->findByAttributes(array('Type_ID'=>$model->Course_Type));
    $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		//'Course_ID',
		'Course_Name',
		array(        
                                                'name' => 'Course_Type',
                                                'value' => CHtml::encode($coursetype->Course_Type)
                                            ),
		'Course_Description',
	),
)); ?>
