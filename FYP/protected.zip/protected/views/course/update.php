<?php
/* @var $this CourseController */
/* @var $model Course */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Course Management'=>array('admin'),
                    'Update '.$model->Course_Name."'s Information",
);

$this->menu=array(
	//array('label'=>'List Course', 'url'=>array('index')),
	array('label'=>'Create New Course', 'url'=>array('create')),
	array('label'=>'View Course', 'url'=>array('view', 'id'=>$model->Course_ID)),
	array('label'=>'Manage Courses', 'url'=>array('admin')),
);
?>

<h1>Update Course, <?php echo $model->Course_Name; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>