<?php
/* @var $this CourseController */
/* @var $model Course */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Course Management'=>array('admin'),
                    'Create New Course',
);

$this->menu=array(
	//array('label'=>'List Course', 'url'=>array('index')),
	array('label'=>'Manage Courses', 'url'=>array('admin')),
);
?>

<h1>Create New Course</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>