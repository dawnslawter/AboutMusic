<?php
/* @var $this CourseController */
/* @var $data Course */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Course_ID), array('view', 'id'=>$data->Course_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_Name')); ?>:</b>
	<?php echo CHtml::encode($data->Course_Name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_Type')); ?>:</b>
	<?php echo CHtml::encode($data->Course_Type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_Description')); ?>:</b>
	<?php echo CHtml::encode($data->Course_Description); ?>
	<br />


</div>