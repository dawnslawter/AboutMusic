<?php
/* @var $this CourseController */
/* @var $model Course */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'Course_ID'); ?>
		<?php echo $form->textField($model,'Course_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Course_Name'); ?>
		<?php echo $form->textArea($model,'Course_Name',array('rows'=>1, 'cols'=>25)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Course_Type'); ?>
		<?php echo $form->dropDownList(
                                                $model,
                                                'Course_Type',
                                                CHtml::listData(
                                                        CourseType::model()->findAll(),
                                                        'Type_ID',
                                                        'Course_Type'
                                                        ),
                                                        array('prompt'=>'Select Course Type')
                                                ); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Course_Description'); ?>
		<?php echo $form->textArea($model,'Course_Description',array('rows'=>2, 'cols'=>50)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->