<?php
/* @var $this NewsletterController */
/* @var $model Newsletter */

$this->breadcrumbs=array(
	'Management'=>array('site/page', 'view'=>'management'),
	'Newsletter Management'=>array('admin'),
	'Update Newsletter',
);

$this->menu=array(
	//array('label'=>'List Newsletter', 'url'=>array('index')),
	array('label'=>'Create New Newsletter', 'url'=>array('create')),
	array('label'=>'View Newsletter', 'url'=>array('view', 'id'=>$model->Img_ID)),
	array('label'=>'Manage Newsletters', 'url'=>array('admin')),
);
?>

<h1>Update Newsletter</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>