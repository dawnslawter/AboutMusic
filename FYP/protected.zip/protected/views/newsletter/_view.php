<?php
/* @var $this NewsletterController */
/* @var $data Newsletter */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Img_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Img_ID), array('view', 'id'=>$data->Img_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Img_Name')); ?>:</b>
	<?php echo CHtml::encode($data->Img_Name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Image')); ?>:</b>
	<?php echo CHtml::encode($data->Image); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Date_Uploaded')); ?>:</b>
	<?php echo CHtml::encode($data->Date_Uploaded); ?>
	<br />


</div>