<?php
/* @var $this NewsletterController */
/* @var $model Newsletter */

$this->breadcrumbs=array(
	'Management'=>array('site/page', 'view'=>'management'),
	'Newsletter Management'=>array('admin'),
	$model->Img_ID,
);

$this->menu=array(
	//array('label'=>'List Newsletter', 'url'=>array('index')),
	array('label'=>'Create New Newsletter', 'url'=>array('create')),
	array('label'=>'Update Newsletter', 'url'=>array('update', 'id'=>$model->Img_ID)),
	array('label'=>'Delete Newsletter', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Img_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Newsletters', 'url'=>array('admin')),
);
?>

<?php
        echo '<h1>View ';
        echo CHtml::link(CHtml::encode('Newsletter #'.$model->Img_ID), Yii::app()->baseUrl . '/images/newsletter/' . $model->Image);
        echo '</h1>';
?>


<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'Img_ID',
		'Img_Name',
		'Image',
                                        'Date_Updated',
		'Date_Uploaded',
	),
)); ?>

