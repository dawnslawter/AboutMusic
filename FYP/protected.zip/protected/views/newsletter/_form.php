<?php
/* @var $this NewsletterController */
/* @var $model Newsletter */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'newsletter-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
                    'htmlOptions' => array(
                            'enctype' => 'multipart/form-data',
    ),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'Img_Name'); ?>
		<?php echo $form->textArea($model,'Img_Name',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'Img_Name'); ?>
	</div>

	<div class="row">
                            <?php echo $form->labelEx($model,'Image'); ?>
                            <?php echo CHtml::activeFileField($model, 'Image'); ?>
                            <?php echo $form->error($model,'Image'); ?>
                    </div>
        
                    <?php if($model->isNewRecord!='1'){ ?>
                    <div class="row">
                         <?php echo CHtml::image(Yii::app()->request->baseUrl.'/../images/newsletter/'.$model->Image,$model->Img_Name,array("width"=>200)); ?>  // Image shown here if page is update page
                    </div>
        
                    <?php } ?>
	

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->