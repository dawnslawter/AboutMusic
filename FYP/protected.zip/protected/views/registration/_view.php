<?php
/* @var $this RegistrationController */
/* @var $data Registration */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('R_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->R_ID), array('view', 'id'=>$data->R_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Student_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Student_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Course_ID); ?>
	<br />


</div>