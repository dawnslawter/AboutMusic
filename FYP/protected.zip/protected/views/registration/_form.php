<?php
/* @var $this RegistrationController */
/* @var $model Registration */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'registration-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'Student_ID'); ?>
		<?php 
                                                $data=Student::model()->findAll();
                                                $arr= array();
                                                foreach($data as $value=>$result){
                                                    $checkchild=Student::model()->findByAttributes(array('Student_ID'=>$result->Student_ID));
                                                    if($checkchild->Child_ID==0){
                                                        $member=UserData::model()->findByAttributes(array('User_ID'=>$result->Member_ID));
                                                        array_push($arr, array('Student_ID'=>$result->Student_ID,'Name'=>$member->First_Name.' '.$member->Last_Name));
                                                    }
                                                    else{
                                                        $child=Child::model()->findByAttributes(array('Member_ID'=>$result->Member_ID,'Child_ID'=>$result->Child_ID));
                                                        array_push($arr, array('Student_ID'=>$result->Student_ID,'Name'=>$child->First_Name.' '.$child->Last_Name));
                                                    }
                                                    
                                                }
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Student_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'Student_ID',
                                                                'Name'
                                                                
                                                                )); 
                                                ?>
		<?php echo $form->error($model,'Student_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Course_ID'); ?>
		<?php 
                                                $course=Course::model()->findAll();
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Course_ID',
                                                        CHtml::listData(
                                                                $course,
                                                                'Course_ID',
                                                                'Course_Name'
                                                                
                                                                )); 
                                        ?>
		<?php echo $form->error($model,'Course_ID'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->