<?php
/* @var $this RegistrationController */
/* @var $model Registration */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Registration Management'=>array('admin'),
	'Update',
);

$this->menu=array(
	//array('label'=>'List Registration', 'url'=>array('index')),
	array('label'=>'Course Registration', 'url'=>array('create')),
	array('label'=>'View Registration', 'url'=>array('view', 'id'=>$model->R_ID)),
	array('label'=>'Manage Registration', 'url'=>array('admin')),
);
?>

<h1>Update Registration <?php echo $model->R_ID; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>