<?php
/* @var $this RegistrationController */
/* @var $model Registration */

$this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
	'Registration Management'=>array('admin'),
	'Registration #'.$model->R_ID,
);

$this->menu=array(
	//array('label'=>'List Registration', 'url'=>array('index')),
	array('label'=>'Course Registration', 'url'=>array('create')),
	array('label'=>'Update Registration', 'url'=>array('update', 'id'=>$model->R_ID)),
	array('label'=>'Delete Registration', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->R_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Registrations', 'url'=>array('admin')),
);
?>

<h1>View Registration #<?php echo $model->R_ID; ?></h1>

<?php 
$checkstud=Student::model()->findByAttributes(array('Student_ID'=>$model->Student_ID));
if($checkstud->Child_ID==0){
    $student=UserData::model()->findByAttributes(array('User_ID'=>$checkstud->Member_ID));
    }
else{
    $student=Child::model()->findByAttributes(array('Member_ID'=>$checkstud->Member_ID,'Child_ID'=>$checkstud->Child_ID));                                                        
       }
$course=Course::model()->findByAttributes(array('Course_ID'=>$model->Course_ID));
            $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		
		array(        
                                                'name' => 'Student',
                                                'value' => CHtml::encode($student->First_Name.' '.$student->Last_Name)
                                            ),
		array(        
                                                'name' => 'Course',
                                                'value' => CHtml::encode($course->Course_Name)
                                            ),
	),
)); ?>
