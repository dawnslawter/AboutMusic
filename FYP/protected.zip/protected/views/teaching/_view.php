<?php
/* @var $this TeachingController */
/* @var $data Teaching */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('T_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->T_ID), array('view', 'id'=>$data->T_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Staff_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Staff_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Course_Type')); ?>:</b>
	<?php echo CHtml::encode($data->Course_Type); ?>
	<br />


</div>