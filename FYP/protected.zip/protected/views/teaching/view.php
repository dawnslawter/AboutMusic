<?php
/* @var $this TeachingController */
/* @var $model Teaching */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Teaching Management'=>array('admin'),
	'View Teaching Relationship',
);

$this->menu=array(
	//array('label'=>'List Teaching', 'url'=>array('index')),
	array('label'=>'Create New Teaching Relationship', 'url'=>array('create')),
	array('label'=>'Update Teaching Relationship', 'url'=>array('update', 'id'=>$model->T_ID)),
	array('label'=>'Delete Teaching Relationship', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->T_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Teaching Relationships', 'url'=>array('admin')),
);
?>

<h1>View Teaching #<?php echo $model->T_ID; ?></h1>

<?php 
$staff=UserData::model()->findByAttributes(array('User_ID'=>$model->Staff_ID));
$coursetype=CourseType::model()->findByAttributes(array('Type_ID'=>$model->Course_Type));
$this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		
		array(        
                                                'name' => 'Staff',
                                                'value' => CHtml::encode($staff->First_Name.' '.$staff->Last_Name)
                                            ),
		array(        
                                                'name' => 'Course_Type',
                                                'value' => CHtml::encode($coursetype->Course_Type)
                                            ),
	),
)); ?>
