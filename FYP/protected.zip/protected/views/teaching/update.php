<?php
/* @var $this TeachingController */
/* @var $model Teaching */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Teaching Management'=>array('admin'),
	'Update Teaching Relationship',
);

$this->menu=array(
	//array('label'=>'List Teaching', 'url'=>array('index')),
	array('label'=>'Create New Teaching Relationship', 'url'=>array('create')),
	array('label'=>'View Teaching Relationship', 'url'=>array('view', 'id'=>$model->T_ID)),
	array('label'=>'Manage Teaching Relationships', 'url'=>array('admin')),
);
?>

<h1>Update Teaching Relationship</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>