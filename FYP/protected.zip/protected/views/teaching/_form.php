<?php
/* @var $this TeachingController */
/* @var $model Teaching */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'teaching-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php
                                        echo $form->labelEx($model,'Staff_ID');
                                                $criteria = new CDbCriteria();
                                                $criteria->condition = 'role>=:id';
                                                $criteria->params = array(':id'=>'3');
                                                $arr = array();
                                                $dat=Login::model()->findAll($criteria);
                                                //$dat= CHtml::listData($dat,'id','id');
                                                
                                                foreach($dat as $value=>$result){
                                                    $teach=UserData::model()->findByAttributes(array('User_ID'=>$result->id));
                                                    
                                                    array_push($arr, array('Staff_ID'=>$teach->User_ID,'Name'=>$teach->First_Name.' '.$teach->Last_Name));
                                                }
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Staff_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'Staff_ID',
                                                                'Name'
                                                                
                                                                )); 
                                                        
                                                
                                        ?>
	</div>

	<div class="row">
		<?php
                                        echo $form->labelEx($model,'Course_Type');
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Course_Type',
                                                        CHtml::listData(
                                                                CourseType::model()->findAll(),
                                                                'Type_ID',
                                                                'Course_Type'
                                                                )); 
                                                        
                                                
                                        ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->