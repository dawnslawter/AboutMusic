<?php
/* @var $this TeachingController */
/* @var $model Teaching */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'T_ID'); ?>
		<?php echo $form->textField($model,'T_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Staff_ID'); ?>
		<?php $criteria = new CDbCriteria();
                                                $criteria->condition = 'role>=:id';
                                                $criteria->params = array(':id'=>'3');
                                                $arr = array();
                                                $dat=Login::model()->findAll($criteria);
                                                //$dat= CHtml::listData($dat,'id','id');
                                                
                                                foreach($dat as $value=>$result){
                                                    $teach=UserData::model()->findByAttributes(array('User_ID'=>$result->id));
                                                    
                                                    array_push($arr, array('Staff_ID'=>$teach->User_ID,'Name'=>$teach->First_Name.' '.$teach->Last_Name));
                                                }
                                                echo $form->dropDownList(
                                                        $model,
                                                        'Staff_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'Staff_ID',
                                                                'Name'
                                                                
                                                                ),
                                                        array('prompt'=>'Select Staff')
                                                        );  ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Course_Type'); ?>
		<?php echo $form->dropDownList(
                                                        $model,
                                                        'Course_Type',
                                                        CHtml::listData(
                                                                CourseType::model()->findAll(),
                                                                'Type_ID',
                                                                'Course_Type'
                                                                ),
                                                        array('prompt'=>'Select Course Type')
                                                        );  ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->