<?php
/* @var $this TeachingController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Teachings',
);

$this->menu=array(
	array('label'=>'Create Teaching', 'url'=>array('create')),
	array('label'=>'Manage Teaching', 'url'=>array('admin')),
);
?>

<h1>Teachings</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
