<?php
/* @var $this TeachingController */
/* @var $model Teaching */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Teaching Management'=>array('admin'),
	'Create New Teaching Relationship',
);

$this->menu=array(
	//array('label'=>'List Teaching', 'url'=>array('index')),
	array('label'=>'Manage Teaching Relationships', 'url'=>array('admin')),
);
?>

<h1>Create New Teaching Relationship</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>