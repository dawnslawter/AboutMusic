<?php
/* @var $this ChildController */
/* @var $model Child */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'child-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>
                    <div class="row">
	<?php
                            echo $form->labelEx($model,'Member_ID');
                            $criteria = new CDbCriteria();
                            $criteria->condition = 'role=:role';
                            $criteria->params = array(':role'=>'2');
                            $arr = array();
                            $dat=Login::model()->findAll($criteria);
                            foreach($dat as $value=>$result){
                                $parent=UserData::model()->findByAttributes(array('User_ID'=>$result->id));
                                  
                                array_push($arr, array('id'=>$parent->User_ID,'Name'=>$parent->First_Name.' '.$parent->Last_Name.' ('.$result->username.')'));
                            }
                            if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                            
                                echo $form->dropDownList(
                                    $model,
                                    'Member_ID',
                                    CHtml::listData(
                                            $arr,
                                            'id',
                                            'Name'
                                            )
                                    );
                            }
                            else{
                                echo $form->dropDownList(
                                    $model,
                                    'Member_ID',
                                    CHtml::listData(
                                            Login::model()->findAll($criteria),
                                            'id',
                                            'Name'
                                            ),
                                        array(
                                  'class'=> 'my-drop-down',
                                  'disabled'=>true
                                  
                              )   
                                    );
                                
                            }
                    ?>
                        </div>
	
                    <div class="row">
		<?php echo $form->labelEx($model,'Child_ID');
                                            if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                                                echo $form->textField($model,'Child_ID');
                                            }
                                            else{
                                                echo $form->textField($model,'Child_ID',array('readonly'=>true));
                                            }
                                            echo $form->error($model,'Child_ID'); 
                                          ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'First_Name'); ?>
		<?php echo $form->textArea($model,'First_Name',array('rows'=>1, 'cols'=>25)); ?>
		<?php echo $form->error($model,'First_Name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Last_Name'); ?>
		<?php echo $form->textArea($model,'Last_Name',array('rows'=>1, 'cols'=>25)); ?>
		<?php echo $form->error($model,'Last_Name'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->