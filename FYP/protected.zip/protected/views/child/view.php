<?php
/* @var $this ChildController */
/* @var $model Child */
if(((Yii::app()->user->role=='member')||(Yii::app()->user->role=='staff'))&&(($model->Member_ID)!==(Yii::app()->user->id))){
    $this->breadcrumbs=array(
                        'No Access'
                );
    echo "<h1>No Authorisation</h1>";
    echo "<div>You do not have permission to view other users' child</div>";
}
else{
    If(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
            $this->breadcrumbs=array(
                            'Management'=>array('site/page','view'=>'management'),
                            'Children Management'=>array('admin'),
                            $model->First_Name.' '.$model->Last_Name,
            );

            $this->menu=array(
                    //array('label'=>'List Child', 'url'=>array('index')),
                    array('label'=>'Create New Child', 'url'=>array('create')),
                    array('label'=>"Update Child's Information", 'url'=>array('update', 'id'=>$model->PC_ID)),
                    array('label'=>'Delete Child', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->PC_ID),'confirm'=>'Are you sure you want to delete this item?')),
                    array('label'=>"Manage Children's Information", 'url'=>array('admin')),
            );
    }
    else{
        $this->breadcrumbs=array(
                            
                            'Your Child',
                            $model->First_Name,
            );

            $this->menu=array(
                    //array('label'=>'List Child', 'url'=>array('index')),
                    //array('label'=>'Create Child', 'url'=>array('create')),
                    array('label'=>"Update Child's Information", 'url'=>array('update', 'id'=>$model->PC_ID)),
                    //array('label'=>'Delete Child', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->PC_ID),'confirm'=>'Are you sure you want to delete this item?')),
                    //array('label'=>'Manage Child', 'url'=>array('admin')),
            );
    }
        
    
}
?>

<h1>
    <?php 
        if((Yii::app()->user->role=='member')&&(($model->Member_ID)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
            if(($model->Member_ID)==(Yii::app()->user->id)){
                echo "Your Child #".$model->Child_ID;
            }
            else{
                echo 'Member '.$model->Member_ID."'s #".$model->Child_ID.' Child, '.$model->First_Name; 
            }
        }
    ?>
</h1>

<?php 
    if((Yii::app()->user->role=='member')&&(($model->Member_ID)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
        $member=login::model()->findByAttributes(array('id'=>$model->Member_ID));
        $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		//'PC_ID',
		array(        
                                                'name' => 'Member_ID',
                                                'header'=>'Member',
                                                'value' => CHtml::encode($member->username)
                                            ),
		'Child_ID',
		'First_Name',
		'Last_Name',
	),
    
    
    
    )); }   
    ?>
