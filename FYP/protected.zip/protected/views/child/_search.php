<?php
/* @var $this ChildController */
/* @var $model Child */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'PC_ID'); ?>
		<?php echo $form->textField($model,'PC_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Member_ID'); ?>
		<?php 
                                                    $criteria = new CDbCriteria();
                                                    $criteria->condition = 'role=:role';
                                                    $criteria->params = array(':role'=>'2');
                                                    $arr = array();
                                                    $dat=Login::model()->findAll($criteria);
                                                    foreach($dat as $value=>$result){
                                                        $parent=UserData::model()->findByAttributes(array('User_ID'=>$result->id));

                                                        array_push($arr, array('id'=>$parent->User_ID,'Name'=>$parent->First_Name.' '.$parent->Last_Name.' ('.$result->username.')'));
                                                    }
                                                    echo $form->dropDownList(
                                                        $model,
                                                        'Member_ID',
                                                        CHtml::listData(
                                                                $arr,
                                                                'id',
                                                                'Name'
                                                                ),
                                                            array('prompt'=>'Select Member')
                                                        );
                                        ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Child_ID'); ?>
		<?php echo $form->textField($model,'Child_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'First_Name'); ?>
		<?php echo $form->textArea($model,'First_Name',array('rows'=>1, 'cols'=>25)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Last_Name'); ?>
		<?php echo $form->textArea($model,'Last_Name',array('rows'=>1, 'cols'=>25)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->