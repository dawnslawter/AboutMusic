<?php
/* @var $this ChildController */
/* @var $data Child */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('PC_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->PC_ID), array('view', 'id'=>$data->PC_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Member_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Member_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Child_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Child_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('First_Name')); ?>:</b>
	<?php echo CHtml::encode($data->First_Name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Last_Name')); ?>:</b>
	<?php echo CHtml::encode($data->Last_Name); ?>
	<br />


</div>