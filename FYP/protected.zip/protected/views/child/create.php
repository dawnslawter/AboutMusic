<?php
/* @var $this ChildController */
/* @var $model Child */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Children Management'=>array('admin'),
	'Create New Child',
);

$this->menu=array(
	
	array('label'=>'Manage Child', 'url'=>array('admin')),
);
?>

<h1>Create New Child</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>