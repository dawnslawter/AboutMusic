<?php
/* @var $this ChildController */
/* @var $model Child */
/* @var $form CActiveForm */

        $this->breadcrumbs=array(
	"Your Children's Profile",
        );
        
        
        
        
        echo '<h1>Your Children</h1>';
        $count=child::model()->countByAttributes(array('Member_ID'=>Yii::app()->user->id));
        $num=1;
        while($num<=$count){
            $result=child::model()->findByAttributes(array('Member_ID'=>Yii::app()->user->id,'Child_ID'=>$num));
            $this->widget('zii.widgets.CDetailView', array(
	'data'=>$result,
	'attributes'=>array(
		
		'Child_ID',
		'First_Name',
		'Last_Name',
	),
    

            ));
            
            echo '<br>';
            echo CHtml::link('Edit',array('child/update','id'=>$result->PC_ID,'date'=>'2'));
            echo '<br><br><br>';
            
            $num++;
        }
        
        
?>

  