<?php
/* @var $this LoginController */
/* @var $model Login */
if(((Yii::app()->user->role=='member')||(Yii::app()->user->role=='staff')||(Yii::app()->user->role=='special'))&&(($model->id)!=(Yii::app()->user->id))){
    $this->breadcrumbs=array(
                        'No Access'
                );
    echo "<h1>No Authorisation</h1>";
    echo "<div>You do not have permission to view other users' account</div>";
}
else{
    If(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
        if(($model->id)==(Yii::app()->user->id)){
            $this->breadcrumbs=array(
                    'Your Account'
            );
        }
        else{
            $this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
                    'User Account Management'=>array('admin'),
                    $model->username,
                );
        }
            $this->menu=array(
                    //array('label'=>'List All User Accounts', 'url'=>array('index')),
                    array('label'=>'Adminstrative'),
                    array('label'=>'Create New Account', 'url'=>array('create')),
                    array('label'=>'Delete User Account', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
                    array('label'=>'Manage Existing User Accounts', 'url'=>array('admin')),
                    array('label'=>'Update'),
                    array('label'=>"Update User's Account", 'url'=>array('update', 'id'=>$model->id)),                 
                    array('label'=>"View User's Profile", 'url'=>array('userData/view', 'id'=>$model->id)),
                    array('label'=>"Update User's Profile", 'url'=>array('userData/update', 'id'=>$model->id)),
            );
    }
    else{
            $this->breadcrumbs=array(
                    'Your Account',
                    
            );

            $this->menu=array(
                //array('label'=>'List All User Accounts', 'url'=>array('index')),
                array('label'=>'Change Password', 'url'=>array('login/update', 'id'=>$model->id)),
                array('label'=>'View Profile', 'url'=>array('userData/view', 'id'=>$model->id)),
                array('label'=>'Update Profile', 'url'=>array('userData/update', 'id'=>$model->id)),
                //array('label'=>'Create New User Account', 'url'=>array('create')),
                
                //array('label'=>'Manage Existing User Accounts', 'url'=>array('admin')),
        );
        }
}
?>

<h1>
    <?php 
        if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->id)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
            if(($model->id)==(Yii::app()->user->id)){
                echo "Your Account";
            }
            else{
            echo $model->username."'s Account"; 
            }
        }
?>
</h1>

<?php 
    if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->id)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
        $role=  Roles::model()->findByAttributes(array('id'=>$model->role));
        $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		
		'username',
		//'password',
		array(        
                                                'name' => 'role',
                                                'value' => CHtml::encode($role->description)
                                            ),
	),
        ));
    }?>
