<?php
/* @var $this LoginController */
/* @var $model Login */

$this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
	'User Account Management'=>('admin'),
	'Create New User Account',
);

$this->menu=array(
	//array('label'=>'List All User Accounts', 'url'=>array('index')),
	array('label'=>'Manage Existing User Accounts', 'url'=>array('admin')),
);
?>

<h1>Create New Account</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>