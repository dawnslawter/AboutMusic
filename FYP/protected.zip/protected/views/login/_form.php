<?php
/* @var $this LoginController */
/* @var $model Login */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'login-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php 
                                        
                                        echo $form->labelEx($model,'username');
                                        if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
		echo $form->textField($model,'username',array('size'=>1,'cols'=>25,'maxlength'=>20));
                                        }
                                        else{
                                        echo $form->textField($model,'username',array('size'=>1,'cols'=>25,'maxlength'=>20,'readonly'=> true));
                                        }
		echo $form->error($model,'username');      
                                        
                                        ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'password'); ?>
		<?php echo $form->passwordField($model,'password',array('size'=>2,'cols'=>25,'maxlength'=>99)); ?>
		<?php echo $form->error($model,'password'); ?>
	</div>
                    <div class="row">
	<?php
                            echo $form->labelEx($model,'role');
                            
                            if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                            echo $form->dropDownList(
                                    $model,
                                    'role',
                                    CHtml::listData(
                                            Roles::model()->findAll(),
                                            'id',
                                            'description'
                                            ),
                              array(
                                  'prompt'=>'Select Role',
                                  'class'=> 'my-drop-down',
                                  
                                  'options' =>array(
                                      '2' => array(
                                          'selected' => "selected"
                                      )
                                  )
                              )      
                                    );
                            }
                            else{
                                echo $form->dropDownList(
                                    $model,
                                    'role',
                                    CHtml::listData(
                                            Roles::model()->findAll(),
                                            'id',
                                            'description'
                                            ),
                              array(
                                  'class'=> 'my-drop-down',
                                  'disabled'=>true,
                                  'options' =>array(
                                      '2' => array(
                                          'selected' => "selected"
                                      )
                                  )
                              )      
                                    );
                            }
                    ?>
                        </div>
	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->