<?php
/* @var $this LoginController */
/* @var $model Login */
if(((Yii::app()->user->role=='member')||(Yii::app()->user->role=='staff')||(Yii::app()->user->role=='special'))&&(($model->id)!=(Yii::app()->user->id))){
    $this->breadcrumbs=array(
                        'No Access'
                );
    echo "<h1>No Authorisation</h1>";
    echo "<div>You do not have permission to update other users' account</div>";
}
else{
        If(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
            $this->breadcrumbs=array(
                    'Management'=>array('site/page','view'=>'management'),
                    'User Account Management'=>array('admin'),
                    'Update User Account',
            );

            $this->menu=array(
                //array('label'=>'List All User Accounts', 'url'=>array('index')),
               array('label'=>'Adminstrative'), 
               array('label'=>'Create New Account', 'url'=>array('create')),
               array('label'=>'Manage Existing User Accounts', 'url'=>array('admin')),
               array('label'=>'Update'),  
               array('label'=>"View User's Account", 'url'=>array('view', 'id'=>$model->id)),
               array('label'=>"View User's Profile", 'url'=>array('userData/view', 'id'=>$model->id)),
               array('label'=>"Update User's Profile", 'url'=>array('userData/update', 'id'=>$model->id)),
               
            );
        }
        else{
            $this->breadcrumbs=array(
                    'Your Account'=>array('view'),
                    'Change Password',
            );

            $this->menu=array(
                //array('label'=>'List All User Accounts', 'url'=>array('index')),
                array('label'=>'View Account', 'url'=>array('view', 'id'=>$model->id)),
                array('label'=>'View Profile', 'url'=>array('userData/view', 'id'=>$model->id)),
                array('label'=>'Update Profile', 'url'=>array('userData/update', 'id'=>$model->id)),
                //array('label'=>'Create New User Account', 'url'=>array('create')),
                
                //array('label'=>'Manage Existing User Accounts', 'url'=>array('admin')),
        );
        }
}



?>

<h1>
    <?php 
        if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->id)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
            if(($model->id)==(Yii::app()->user->id)){
                if((Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
                    echo "Update Your Account";
                }
                else{
                    echo "Change Password";
                }
            }
            else{
            echo "Update ".  $model->username."'s Account"; 
            }
        }
?>
</h1>

<?php 
if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->id)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
        $this->renderPartial('_form', array('model'=>$model)); 
}
?>