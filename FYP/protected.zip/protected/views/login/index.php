<?php
/* @var $this LoginController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'User Account Management',
);

$this->menu=array(
	array('label'=>'Create New User Account', 'url'=>array('create')),
	array('label'=>'Manage Existing User Accounts', 'url'=>array('admin')),
);
?>

<h1>Existing User Accounts</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
