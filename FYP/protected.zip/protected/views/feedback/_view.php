<?php
/* @var $this FeedbackController */
/* @var $data Feedback */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('Feedback_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->Feedback_ID), array('view', 'id'=>$data->Feedback_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Attendance_ID')); ?>:</b>
	<?php echo CHtml::encode($data->Attendance_ID); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Feedback')); ?>:</b>
	<?php echo CHtml::encode($data->Feedback); ?>
	<br />


</div>