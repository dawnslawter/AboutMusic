<?php
/* @var $this UserDataController */
/* @var $model UserData */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'user-data-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'First_Name'); ?>
		<?php echo $form->textArea($model,'First_Name',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'First_Name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Last_Name'); ?>
		<?php echo $form->textArea($model,'Last_Name',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'Last_Name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'MobileNo'); ?>
		<?php echo $form->textField($model,'MobileNo'); ?>
		<?php echo $form->error($model,'MobileNo'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'TelNo'); ?>
		<?php echo $form->textField($model,'TelNo'); ?>
		<?php echo $form->error($model,'TelNo'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Email'); ?>
		<?php echo $form->textField($model,'Email',array('size'=>60,'maxlength'=>99)); ?>
		<?php echo $form->error($model,'Email'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Address1');
                                        if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                                            echo $form->textField($model,'Address1',array('size'=>60,'maxlength'=>99));
                                        }
                                        else{
                                            echo $form->textField($model,'Address1',array('size'=>60,'maxlength'=>99,'readonly'=> true));
                                        }
		echo $form->error($model,'Address1'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Address2');
                                        if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                                            echo $form->textField($model,'Address2',array('size'=>60,'maxlength'=>99));
                                        }
                                        else{    
                                            echo $form->textField($model,'Address2',array('size'=>60,'maxlength'=>99,'readonly'=> true));
                                        }
		echo $form->error($model,'Address2'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'Address3');
		if(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                                            echo $form->textField($model,'Address3',array('size'=>60,'maxlength'=>99));
                                        }
                                        else{    
                                            echo $form->textField($model,'Address3',array('size'=>60,'maxlength'=>99,'readonly'=> true));
                                        }
		echo $form->error($model,'Address3'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->