<?php
/* @var $this UserDataController */
/* @var $model UserData */

//Header
if(((Yii::app()->user->role=='member')||(Yii::app()->user->role=='staff'))&&(($model->User_ID)!=(Yii::app()->user->id))){
    $this->breadcrumbs=array(
                        'No Access'
                );
    echo "<h1>No Authorisation</h1>";
    echo "<div>You do not have permission to update other users' profile</div>";
    
}
else{
            if(($model->User_ID)==(Yii::app()->user->id)){
                        $this->breadcrumbs=array(
                                'Update Your Profile'
                        );
                        
                        $this->menu=array(
	
                    array('label'=>"View Account", 'url'=>array('login/view', 'id'=>$model->User_ID)),        
                    array('label'=>'Change Password', 'url'=>array('login/update', 'id'=>$model->User_ID)),        
	array('label'=>'View Profile', 'url'=>array('view', 'id'=>$model->User_ID)),
                    //array('label'=>'List UserData', 'url'=>array('index')),
	//array('label'=>'Create UserData', 'url'=>array('create')),        
	//array('label'=>'Manage UserData', 'url'=>array('admin')),
                    
    );
            }
            else{
                $this->breadcrumbs=array(
                    'User Datas'=>array('index'),
                    $model->User_ID=>array('view','id'=>$model->User_ID),
                    'Update',
                    );
                $this->menu=array(
                    //array('label'=>'List UserData', 'url'=>array('index')),
	//array('label'=>'Create UserData', 'url'=>array('create')),
                    array('label'=>"View User's Account", 'url'=>array('login/view', 'id'=>$model->User_ID)),
                    array('label'=>"Update User's Account", 'url'=>array('login/view', 'id'=>$model->User_ID)),      
	array('label'=>"View User's Profile", 'url'=>array('view', 'id'=>$model->User_ID)),
	array('label'=>'Manage UserData', 'url'=>array('admin')),
                );
                }
}
?>


<?php//Content?>
<h1>
    <?php 
        if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->User_ID)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
            if(($model->User_ID)==(Yii::app()->user->id)){
                echo "Update Your Profile";
            }
            else{
            echo "Update ".  $model->First_Name."'s Profile"; 
            }
        }
?>
</h1>

<?php 
if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->User_ID)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
        $this->renderPartial('_form', array('model'=>$model)); 
}
?>