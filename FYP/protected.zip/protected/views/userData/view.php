<?php
/* @var $this UserDataController */
/* @var $model UserData */

if(((Yii::app()->user->role=='member')||(Yii::app()->user->role=='staff'))&&(($model->User_ID)!=(Yii::app()->user->id))){
    $this->breadcrumbs=array(
                        'No Access'
                );
    echo "<h1>No Authorisation</h1>";
    echo "<div>You do not have permission to view other users' profile</div>";
}
else{
        //check whether accessing own profile
    If(Yii::app()->user->role=='admin'||Yii::app()->user->role=='superadmin'){
                if(($model->User_ID)==(Yii::app()->user->id)){
                        $this->breadcrumbs=array(
                                'Your Profile'
                        );
                }
                else{
                    $this->breadcrumbs=array(
                        'User Management'=>array('site/page','view'=>'usermanagement'),
                        'User Profile Management'=>array('admin'),
                        $model->First_Name.' '.$model->Last_Name
                    );

                }
                $this->menu=array(
                                //array('label'=>'List UserData', 'url'=>array('index')),
                                //array('label'=>'Create UserData', 'url'=>array('create')),
                                array('label'=>"Adminstrative"),
                                array('label'=>"Manage User Profiles", 'url'=>array('admin')),
                                array('label'=>'Delete UserData', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->User_ID),'confirm'=>'Are you sure you want to delete this item?')),
                                array('label'=>"Update"),
                                array('label'=>"View User's Account", 'url'=>array('login/view', 'id'=>$model->User_ID)),
                                array('label'=>"Update User's Account", 'url'=>array('login/update', 'id'=>$model->User_ID)),
                                array('label'=>"Update User's Profile", 'url'=>array('update', 'id'=>$model->User_ID)),

                        );
        
        
    }
    else{
        $this->breadcrumbs=array(
                        'Your Profile'
                );
        $this->menu=array(
                        //array('label'=>'List UserData', 'url'=>array('index')),
                        //array('label'=>'Create UserData', 'url'=>array('create')),
                        array('label'=>'View Account Details', 'url'=>array('login/view', 'id'=>$model->User_ID)),
                        array('label'=>'Change Password', 'url'=>array('login/update', 'id'=>$model->User_ID)),
                        array('label'=>'Update Profile', 'url'=>array('update', 'id'=>$model->User_ID)),
                
                        //array('label'=>'Delete UserData', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->User_ID),'confirm'=>'Are you sure you want to delete this item?')),
                        //array('label'=>'Manage UserData', 'url'=>array('admin')),
                );

            }
        }
        ?>

<h1>
    <?php 
        if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->User_ID)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
            if(($model->User_ID)==(Yii::app()->user->id)){
                echo "Your Profile";
            }
            else{
            echo $model->First_Name."'s Account"; 
            }
        }
    ?>
</h1>

        <?php 
            if((Yii::app()->user->role=='member'||Yii::app()->user->role=='staff'||Yii::app()->user->role=='special staff')&&(($model->User_ID)==(Yii::app()->user->id))||(Yii::app()->user->role=='admin')||(Yii::app()->user->role=='superadmin')){
            $this->widget('zii.widgets.CDetailView', array(
                'data'=>$model,
                'attributes'=>array(
                        'First_Name',
                        'Last_Name',
                        'MobileNo',
                        'TelNo',
                        'Email',
                        'Address1',
                        'Address2',
                        'Address3',
                ),
            )); }



?>
