<?php
/* @var $this UserDataController */
/* @var $model UserData */

$this->breadcrumbs=array(
	'User Management'=>array('site/page','view'=>'usermanagement'),
	'User Account Management'=>('login/admin'),
	'Create New User Account',
);

$this->menu=array(
	//array('label'=>'List UserData', 'url'=>array('index')),
	//array('label'=>'Manage UserData', 'url'=>array('admin')),
);
?>

<h1>Fill in User's Profile</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>