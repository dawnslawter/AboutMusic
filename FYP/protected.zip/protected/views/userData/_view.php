<?php
/* @var $this UserDataController */
/* @var $data UserData */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('User_ID')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->User_ID), array('view', 'id'=>$data->User_ID)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('First_Name')); ?>:</b>
	<?php echo CHtml::encode($data->First_Name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Last_Name')); ?>:</b>
	<?php echo CHtml::encode($data->Last_Name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('MobileNo')); ?>:</b>
	<?php echo CHtml::encode($data->MobileNo); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TelNo')); ?>:</b>
	<?php echo CHtml::encode($data->TelNo); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Email')); ?>:</b>
	<?php echo CHtml::encode($data->Email); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Address1')); ?>:</b>
	<?php echo CHtml::encode($data->Address1); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('Address2')); ?>:</b>
	<?php echo CHtml::encode($data->Address2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Address3')); ?>:</b>
	<?php echo CHtml::encode($data->Address3); ?>
	<br />

	*/ ?>

</div>