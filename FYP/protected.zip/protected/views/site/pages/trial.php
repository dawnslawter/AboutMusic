<?php
/* @var $this SiteController */
/* @var $error array */

$this->pageTitle=Yii::app()->name . ' - Trial Functions';
$this->breadcrumbs=array(
	'Function Testing',
);


?>

<h2>Function Test</h2>

<div>
    <?php echo "Ajax Testing"?>
    <?php echo CHtml::link('Go',array('site/page','view'=>'parents')); ?>
    <?php echo "<br><br>"?>
</div>

<div>
    <?php echo "Attendance Taking"?>
    <?php echo CHtml::link('Go',array('site/page','view'=>'trial2')); ?>
    <?php echo "<br><br>"?>
</div>
<div>
    <?php echo "Uploader"?>
    <?php echo CHtml::link('Go',array('newsletter/admin')); ?>
    <?php echo "<br><br>"?>
</div>
