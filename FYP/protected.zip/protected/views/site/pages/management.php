<?php
/* @var $this SiteController */
/* @var $error array */

$this->pageTitle=Yii::app()->name . ' - User Management';
$this->breadcrumbs=array(
	'Management',
);


?>
<table style='width:900px'>
    <tr>
       <td style='width: 300px'>
            <h2>User Related</h2>
        </td>
        <td style='width: 300px'>
            <h2>Course Related</h2>
        </td>
        <td style='width: 300px'>
            <h2>Lesson Related</h2>
        </td>
    </tr>
    <tr>
        <td>
            <div>
                <?php echo CHtml::link('User Account Management',array('login/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>

                <?php echo CHtml::link('User Profile Management',array('userdata/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>

                <?php echo CHtml::link('Children Management',array('child/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>

                <?php echo CHtml::link('Student Management',array('student/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
        </td>
        <td>
            <div>
                <?php echo CHtml::link('Course Management',array('course/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>
                <?php echo CHtml::link('Course Type Management',array('courseType/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>

                <?php echo CHtml::link('Teaching Management',array('teaching/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>

                <?php echo CHtml::link('Registration Management',array('registration/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
        </td>
        <td>
            <div>
                <?php echo CHtml::link('Lesson Management',array('timetable/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>
                <?php echo CHtml::link('Attendance Management',array('attendance/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>
                <?php echo CHtml::link('Feedback Management',array('feedback/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
        </td>
    </tr>
    <tr>
        <td>
            <h2>Adminstrative Related</h2>
        </td>
        <td>
            <h2></h2>
        </td>
        <td>
            <h2></h2>
        </td>
    </tr>
    <tr>
        <td>
            <div>
                <?php echo CHtml::link('Newsletter Management',array('newsletter/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
            <div>

                <?php echo CHtml::link('Studio Management',array('studio/admin')); ?>
                <?php echo "<br><br>"?>
            </div>
           
        </td>
        <td>
            
        </td>
        <td>
            
        </td>
    </tr>
</table>