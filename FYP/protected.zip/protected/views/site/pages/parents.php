<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<h1>About</h1>


<form>

<input type="checkbox" id="first" /><label for="first">First Box</label> <br>
<input type="checkbox" id="second" /><label for="second">First Box</label> <br>

<input type="text" id="output" value="5.00"/>

</form>

<script type="text/javascript">
  var first = document.getElementById("first");
  var second = document.getElementById("second");

  first.onchange = function () {
    if (this.checked == true) {
        document.getElementById("output").value = "new Value";
    }else {
        document.getElementById("output").value = "other Value";
    }
  }

second.onchange = function () {
    if (this.checked == true) {
        document.getElementById("output").value = "new Value";
    }else {
        document.getElementById("output").value = "other Value";
    }
  }
  
</script>


<?php
    $parentid= Yii::app()->user->id;
    echo $parentid;
    
    
?>

<div><input type="button" id="add" value="Add"/></div>

<?php
$num = 1; 
?>
<script type="text/javascript">
  var add = document.getElementById("add");

  add.onClick = function () {
    if (this.checked == true) {
        num++;
    }
  }
  
 
</script>

<?php
     echo $num;
?>