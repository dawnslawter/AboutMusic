<?php
/* @var $this SiteController */
/* @var $error array */

$this->pageTitle=Yii::app()->name . ' - Error';
$this->breadcrumbs=array(
	'Registeration Error',
);
?>

<h2>Registration Error</h2>

<div class="error">
    <?php echo "Username Exists. Try other using other username.<br><br>"?>
    <?php echo CHtml::link('Go Back',array('login/admin')); ?>
</div>