<?php
/* @var $this CourseTypeController */
/* @var $model CourseType */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Course Type Management'=>array('admin'),
	'Create New Course Type'
);

$this->menu=array(
	//array('label'=>'List CourseType', 'url'=>array('index')),
	array('label'=>'Manage CourseType', 'url'=>array('admin')),
);
?>

<h1>Create New Course Type</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>