<?php
/* @var $this CourseTypeController */
/* @var $model CourseType */

$this->breadcrumbs=array(
	'Course Management'=>array('site/page','view'=>'coursemanagement'),
	'Course Type Management'=>array('admin'),
	$model->Course_Type,
);

$this->menu=array(
	//array('label'=>'List CourseType', 'url'=>array('index')),
	array('label'=>'Create New Course Type', 'url'=>array('create')),
	array('label'=>'Update Course Type', 'url'=>array('update', 'id'=>$model->Type_ID)),
	array('label'=>'Delete Course Type', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->Type_ID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Course Types', 'url'=>array('admin')),
);
?>

<h1>View Course Type #<?php echo $model->Type_ID; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		
		'Course_Type',
	),
)); ?>
