<?php
/* @var $this CourseTypeController */
/* @var $model CourseType */

$this->breadcrumbs=array(
	'Management'=>array('site/page','view'=>'management'),
	'Course Type Management'=>array('admin'),
	'Update '.$model->Course_Type,
);

$this->menu=array(
	//array('label'=>'List CourseType', 'url'=>array('index')),
	array('label'=>'Create New Course Type', 'url'=>array('create')),
	array('label'=>'View Course Type', 'url'=>array('view', 'id'=>$model->Type_ID)),
	array('label'=>'Manage Course Type', 'url'=>array('admin')),
);
?>

<h1>Update Course Type, <?php echo $model->Course_Type; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>