<?php
/* @var $this CourseTypeController */
/* @var $model CourseType */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'Type_ID'); ?>
		<?php echo $form->textField($model,'Type_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'Course_Type'); ?>
		<?php echo $form->textArea($model,'Course_Type',array('rows'=>1, 'cols'=>25)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->